import React, {Component} from 'react'

class Footer extends Component {
    render() {
        return (
            <footer>SeenIt SPA &copy; 2017</footer>
        )
    }
}

export default Footer